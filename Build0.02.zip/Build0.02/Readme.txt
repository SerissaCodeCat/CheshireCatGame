/////////////////////////////////////////////////////////////
/////////////////////Controls////////////////////////////////
/////////////////////////////////////////////////////////////

Escape / start = Open Menu (currently only exits game) 
WASD / left stick / dPad = MOVE
Shift / leftTrigger = Stealth
Right Mouse / Right Trigger (HOLD) = move teleport destination
Left Ctrl / Right Shoulder (HOLD) = Aim rock 
Space / button_South = Jump
Left Mouse Button / Button_West = Activate/Fire/Teleport

/////////////////////////////////////////////////////////////
//////////////////// AIM OF BUILD////////////////////////////
/////////////////////////////////////////////////////////////

- the aim of this build is not to locate bugs but any bugs reported will be noted.

- the aim of this build is to test the controls and the "feel" of moving around in the world

- suggestions for improvements to the feel will be looked at, but not nessisarily acted upon

- if no comment is made, that is not a failure of the tester, agreeing with the current feel is OK
